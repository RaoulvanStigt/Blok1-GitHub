
alert('Hallo! Vul deze vragen in!')

var voornaam = prompt('Vul je voornaam in');
var achternaam = prompt('Vul je achternaam in');
var leeftijd = prompt('Vul je leeftijd in');

document.writeln('Wat is jou voornaam:')
document.writeln(voornaam)
document.write('<br>')
document.writeln('Wat is jou achternaam:')
document.writeln(achternaam)
document.write('<br>') 
document.writeln('Wat is jou leeftijd:')
document.writeln(leeftijd)



//document.write (prompt ('Vul je achternaam in'));
//document.write (prompt ('Wat is je leeftijd?'));




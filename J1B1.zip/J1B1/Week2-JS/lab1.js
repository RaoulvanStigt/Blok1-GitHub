
alert('Vul deze vragen in')  


document.write (prompt ('Vul je voornaam in'));
document.write (prompt ('Vul je achternaam in'));
document.write (prompt ('Wat is je leeftijd?'));



var tafel = prompt('Vul een getal in');

document.write ('<br>1 x ' + tafel + ' = ' + 1 * tafel); // 1x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 2 * tafel); // 2x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 3 * tafel); // 3x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 4 * tafel); // 4x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 5 * tafel); // 5x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 6 * tafel); // 6x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 7 * tafel); // 7x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 8 * tafel); // 8x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 9 * tafel); // 9x de tafel
document.write ('<br>1 x ' + tafel + ' = ' + 10 * tafel); // 10x de tafel



Week 3

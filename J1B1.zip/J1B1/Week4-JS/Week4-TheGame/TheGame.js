var input = prompt("Je bent in een gevaarlijke grot gekomen. Je probeert er levend uit te komen. Je ziet een tafel met 3 wapens:                                                1) Mes  2) Knuppel 3) Kruisboog")

	if (input == "1") {
   		var input = alert  (" Je gaat verder, maar het mes dat je hebt gekozen is van plastic! FAILED")
   		document.write (" <br> Het mes dat je hebt gekozen is van plastic!")
	}
	else if (input == "2") {
	alert ("Goede keuze! Ga verder!")
    document.write (" <br> Je hebt gekozen voor de knuppel!")
    }
    else if  (input == "3") {
     var input = alert ("De kruisboog heeft geen pijlen! Daar kan je niet zo veel mee! FAILED")
    document.write ("<br> De kruisboog heeft geen pijlen! Daar kan je niet zo veel mee!")
	}
    		
 if (input == '2')  	
var input = prompt ("Je ziet 3 deuren met manieren om dood te gaan:    1) mensen slaan je met knuppels   2) Een kogel door je hoofd    3) Je komt in een hok met leeuwen die al 3 jaar niet gegeten hebben")			
			
			if (input == "1") {
    			var input = alert ("Je probeert de overvallers te slaan, maar er zijn er te veel. Je gaat dood! FAILED")
    			document.write (" <br> Je probeert de overvallers te slaan, maar er zijn er te veel. Je gaat dood!")
			}
			else if (input == "2") {
    			var input = alert ("Helaas! Een kogel door je hoofd! Dat zou ik niet nog een keer doen! FAILED")
    			document.write (" <br> Helaas! Een kogel door je hoofd! Dat zou ik niet nog een keer doen!")
			}
			else if (input == "3") {
    			alert ("De leeuwen zijn allang dood, want zolang kunnen ze niet zonder eten! Ga verder!")
    			document.write ("<br> De leeuwen zijn allang dood, want zolang kunnen ze niet zonder eten!")
			}



if (input == '3'){
var input = prompt ("ONEE! Je komt een zombie tegen wat doe je?                            1) Je slaat hem met je knuppel    2) Je rent weg   3) Je blijft rustig zitten tot de zombie weg gaat")
}	
			if (input == "1") {
    			var input = alert ("Je slaat hem met de knuppel! Hij lijkt dood! Maar hij staat op! De zombie eet je hersens op! FAILED")
    			document.write (" <br> Je hebt de goede keuze gemaakt om de knuppel te pakken! Maar het pakte niet goed uit! Je bent echt een knuppel!")
			}
			else if (input == "2") {
    			var input = alert (" Je probeert weg te rennen! Je valt over een skelet van de één leeuwen! De zombie pakt je en eet je hersens op! FAILED")
				document.write (" <br> Je probeert weg te rennen! Je valt over een skelet van de één leeuwen! De zombie pakt je en eet je hersens op!")
			}
			else if (input == "3") {
    			alert ("Je blijft zitten. De zombie loopt weg! Je gaat verder!")
    			document.write (" <br> Je blijft zitten. De zombie loopt weg!")
			}

if (input == '3'){
var input = prompt ("Je loopt door! Je ziet water!                                                           1) Je kan gaan zwemmen en kijken of er een uitgang is                2) Je blijft zitten. Wat doe je? ")
}
			if (input == "1") {
    			alert ("Je besluit te gaan zwemmen. Je ziet een schaduw in het water! Je wordt bang en spartelt weg.")
				document.write (" <br> Je besluit te gaan zwemmen. Je ziet een schaduw in het water! Je wordt bang en spartelt weg")
			}

			else if (input == "2") {
    			var input = alert ("Je besluit te blijven zitten. Je wordt moe! Je gaat slapen! En je wordt nooit meer wakker! FAILED")
				document.write (" <br> Je besluit te blijven zitten. Je wordt moe! Je gaat slapen! En je wordt nooit meer wakker!")
			}

if (input == '1'){					
 var input = prompt ("De schaduw is weg je kan terug zwemmen of door zwemmen. Wat doe je?                                                                           1) Terug zwemmen 2) Door zwemmen")
}						
						if (input == "1") {
    					var input = alert (" Je hebt besloten om terug te zwemmen! Het wordt donkerder in de grot! Je ziet niks! Je benen worden moe! Je hebt geen energie meer over. Je verdrinkt! FAILED ")
    					document.write (" <br> Je hebt besloten om terug te zwemmen! Het wordt donkerder in de grot! Je ziet niks! Je benen worden moe! Je hebt geen energie meer over. Je verdrinkt! ")
    					}

						else if (input == "2") {
    						alert (" Je hebt besloten om door te zwemmen! Je ziet licht! Het lijkt op een uitgang! ")
    						alert ("Het is een zaklamp! Het lijkt erop alsof er nog iemand in de grot zit!")	
							alert ("Een eindje verder op zie je een meisje op de grond liggen met schaafwonden op haar gezicht!")		
							alert (" Je loopt rustig op het meisje af. Ze ziet er bang uit. Je komt dichterbij. Ze rent weg!")
							prompt ("Wat doe je?                      1) erachteraan rennen            2)  wegrennen")
							alert (" Je gaat er achteraan! Je hebt totaal geen conditie. Je wordt moe en stopt met lopen. Je loopt terug.")
							alert ("Je hoort iets achter je. Je ziet het meisje staan! Ze ziet er helemaal gezond uit. Hoe kan dit?")
							alert ("Je loopt op het meisje af en vraagt wat er aan de hand is.")
							alert ("Het meisje verandert in een villager. Je krijgt een map naar de uitgang")
							alert ("EINDE")
							document.write (" <br> Goedzo! Je hebt de uitgang gevonden!")
    					}
 
		

var geel = prompt("Is de kaas geel?")


	if (geel == "ja") {
    var gaten = prompt ("Heeft de kaas gaten?")
	}
	else if (geel == "nee") {
    var blauweSchimmel = prompt ("Heeft de kaas Blauwe Schimmel?")
	}

		if (gaten == "ja") {
   	 	var durekaas = prompt ("Is de kaas belaschelijk duur?")
    	}
		else if (gaten == "nee") {
    	var steenkaas = prompt ("Is de kaas hard als steen?")
    	}

		if (blauweSchimmel == "ja") {
   	 	var tweedekorst = prompt ("Heeft de kaas een korst?")
    	}
		else if (blauweSchimmel == "nee") {
    	var Korst = prompt ("Heeft de kaas een korst?")
    	}


			if (tweedeKorst == "ja") {
    		document.write ("Dit is Bleu de Rockbaron")
			}
			else if (tweedeKorst == "nee"){
			document.write ("Dit is Foume d'Ambert")
			}
    		
    		if (Korst == "ja") {
    		document.write ("Dit is Camembert")
			}
			else if (Korst == "nee"){
			document.write ("Dit is Mozzarella")
			}

			if (dureKaas == "ja") {
    		document.write ("Dit is Emmenthaler")
			}
			else if (dureKaas == "nee"){
			document.write ("Dit is Leerdammer")
			}

			if (steenKaas == "ja") {
    		document.write ("Dit is Pammigiano Reggiano")
			}
			else if (steenKaas == "nee"){
			document.write ("Dit is Goudse kaas")
			}

			


















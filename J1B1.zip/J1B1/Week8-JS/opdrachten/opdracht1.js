
function helloWorld(getal){
	for (var i = 1; i <= getal; i++){
	document.write (i + ' .Hello World <br>')
	}
}

helloWorld(500000);



table = prompt ('Vul hier een tafel in. Tussen de 1 en de 10....')


if (table > 10) { 
	alert ('Dit is geen getal tussen 1 en 10....')
	
	while (table > 10) {
		table = prompt ('Vul hier een tafel in. Tussen de 1 en de 10....')
	}

	if (table <= 10) {
		for (var j=1; j <= table; j++) {
		createTable(j);
		document.write ('<br>')
		}
	}

	else if (table > 10) {
	alert ('Dit is geen getal tussen 1 en 10....')
	}
	
}

else if (table <= 10) {
		for (var j=1; j <= table; j++) {
		createTable(j);
		document.write ('<br>')
		}
	}








function createTable(getal) {
	for (var i=1; i <= 10; i++) {
		document.write (i + ' x ' + getal + ' = ' + getal*i + '<br>')
	}
}



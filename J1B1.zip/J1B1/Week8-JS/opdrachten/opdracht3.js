var name;
var age;


while (name != 'stop') { 
	name = prompt ('Wat is je naam?')
	
	if (name != 'stop') {
	age = prompt ('Wat is je leeftijd?')
	nameAndAge();
	}
}	
	
function nameAndAge (){
	document.write ('Hallo ' + name + ', je leeftijd is ' + age + ' jaar<br>')
}


var add = add (10, 12);
var sub = sub (58, 34);
var multi = multi (6, 7);
var div = div (144, 12);
var inc = inc (12);
var dec = dec (34);

function add (number1, number2) {
	return (number1 + number2)
}

function sub (number1, number2) {
	return (number1 - number2)
}

function multi (number1, number2) {
	return (number1 * number2)
}

function div (number1, number2) {
	return (number1 / number2)
}

function inc (number1) {
	return (number1 + 1)
}

function dec (number1) {
	return (number1 - 1)
}


document.write ('10 + 12 = ' + add + '<br>')
document.write ('58 - 34 = ' + sub + '<br>')
document.write ('6 x 7 = ' + multi + '<br>')
document.write ('144 / 12 = ' + div + '<br>')
document.write ('10 + 1 = ' + inc + '<br>')
document.write ('10 - 1 = ' + dec + '<br>')


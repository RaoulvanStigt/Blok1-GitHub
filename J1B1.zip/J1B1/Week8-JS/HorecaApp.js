var aantalFris = 0;
var aantalBier = 0;
var aantalWijn = 0;

var aantalKleineSchalen = 0;
var aantalGroteSchalen = 0;

const prijsFris = 2.20;
const prijsBier = 2.50;
const prijsWijn = 4.50;

const prijsKleineSchalen = 6.00;
const prijsGroteSchalen = 10.00;


bestelling();



function bestelling () {
	while (bestelling != 'stop') {
		var bestelling = prompt ('Wat wilt u bestellen?')

		if (bestelling == 'fris') { 
			aantalFris = aantalFris + parseInt(prompt ('Hoeveel fris wilt u toevoegen aan uw bestelling?'))
		}

		else if (bestelling == 'bier') { 
			aantalBier = aantalBier + parseInt (prompt ('Hoeveel bier wilt u toevoegen aan uw bestelling?'))
		}

		else if (bestelling == 'wijn') { 
			aantalWijn = aantalWijn + parseInt(prompt ('Hoeveel wijn wilt u toevoegen aan uw bestelling?'))
		}

		else if (bestelling == 'snack') { 
			addSnackToOrder();
		}
		
		else if (bestelling == 'stop'){
   			priceTotal();
        }
   		else{
    		alert('Onze Excuses, wij hebben geen ' + bestelling + ' vandaag.')
    	}
	}
}




function addSnackToOrder() {
	input = parseInt(prompt ('Hoeveel bitterballen wilt u toevoegen (8 of 16)?'))
			
			if (input  == '8') {
				aantalKleineSchalen = aantalKleineSchalen + parseInt(prompt ('Hoeveel schalen van 8 bitterballen wilt u toevoegen aan uw bestelling?'))
			}
			else if (input  == '16') {
				aantalGroteSchalen = aantalGroteSchalen + parseInt(prompt ('Hoeveel schalen van 16 bitterballen wilt u toevoegen aan uw bestelling?'))
			}
			else {
				alert ('U kunt alleen kiezen tussen 8 of 16 bitterballen')
			}
		}


function priceTotal(){
    if(aantalFris >= 1){
        document.write('Prijs totaal Fris: €' + prijsFris*aantalFris + ' <br>Aantal fris: ' + aantalFris + '<br><br>')
	}
    if(aantalBier >= 1){
        document.write('Prijs totaal Bier: €' + prijsBier*aantalBier + ' <br>Aantal bier: ' + aantalBier + '<br><br>')
	}
   	if(aantalWijn >= 1){
        document.write('Prijs totaal Wijn: €' + prijsWijn*aantalWijn + ' <br>Aantal wijn: ' + aantalWijn + '<br><br>')
	}
    if(aantalKleineSchalen >= 1){
        document.write('Prijs schalen van 8 bitterballen: €' + prijsKleineSchalen*aantalKleineSchalen + '<br> Aantal schalen met 8 bitterballen: ' + aantalKleineSchalen + '<br><br>')
	}
   if(aantalGroteSchalen >= 1){
        document.write('Prijs schalen van 16 bitterballen: €' + prijsGroteSchalen*aantalGroteSchalen + '<br> Aantal schalen met 16 bitterballen: ' + aantalGroteSchalen + '<br><br>')
	}
	var totaal = prijsFris*aantalFris + prijsBier*aantalBier + prijsWijn*aantalWijn + prijsKleineSchalen*aantalKleineSchalen + prijsGroteSchalen*aantalGroteSchalen

	document.write ('___________________________________<br><br>')
    document.write('Totaal: €' + totaal)
}



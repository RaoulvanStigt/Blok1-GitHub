var number = prompt ("Vul hier een getal in...")

for (var i=1; i <= 10; i++) {
	document.write ('<br>' +number*i)
}